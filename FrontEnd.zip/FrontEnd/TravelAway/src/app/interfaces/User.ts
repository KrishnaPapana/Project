export interface User {
  FirstName: string;
  LastName: string;
  EmailId: string;
  UserPassword: string;
  Gender: string;
  ContactNo: number;
  DateOfBirth: Date;
  Address: string;
}

export interface BookAccommodation {
  BookingId: string;
  HotelId: string;
  HotelName: string;
  CityName: string;
  Rating: Number;
  Cost: Number;
  RoomType: string;
}

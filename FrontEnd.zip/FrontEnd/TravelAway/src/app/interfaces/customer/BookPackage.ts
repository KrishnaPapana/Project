export interface BookPackage {
  EmailId: string;
  ContactNo: string;
  Address: string;
  NoOfChildren: Number;
  NoOfAdult: Number;
  DateOfTravel: Date;
  PackageId: string;
  AccomodationId: string;
  
}

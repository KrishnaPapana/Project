export interface Accomodation {
  hotelId: string;
  hotelName: string;
  cityName: string;
  rating: Number;
  singleRoomPrice: Number;
  doubleRoomPrice: Number;
  deluxeRoomPrice: Number;
  suiteRoomPrice: Number;
  accommodations: [];
}

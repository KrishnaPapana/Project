export interface CustomerCare {

  BookingId: string;
  Status: string;
  Question: string;

}

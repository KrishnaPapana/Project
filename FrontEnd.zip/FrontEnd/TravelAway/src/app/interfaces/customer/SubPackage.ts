export interface SubPackage {
  packageId: string;
  packageName: string;
  placesToVisit: string;
  subPackageDescription: string,
  details: string;
  price: Number;
  packageNameNavigation: string;
  bookPackage: any
}

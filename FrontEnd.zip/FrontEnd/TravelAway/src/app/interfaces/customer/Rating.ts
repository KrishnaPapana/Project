export interface Rating {
  BookingId: string;
  Comment: string;
  Stars: Number;

}

export interface Payment {
  bookingId: string;
  totalAmount: string;

}

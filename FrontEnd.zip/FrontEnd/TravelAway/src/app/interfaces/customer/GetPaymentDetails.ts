export interface PaymentDetails {
  BookingId: string;
  AccommodationId: string;
}

export interface LoginUser {
 
  EmailId: string;
  Password: string;
}

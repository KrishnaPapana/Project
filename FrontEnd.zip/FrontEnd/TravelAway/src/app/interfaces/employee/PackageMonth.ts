export interface PackageMonth {
  month: string;
  numberOfBooking: string;
}

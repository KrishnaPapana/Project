export interface Vehicle {
  vehicleName: string;
  vehicleType: string;
  pricePerKm: string;
  pricePerHr: string;
}

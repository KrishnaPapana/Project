export interface Hotel {
  hotelName: string;
  hotelRating: string;
  singleRoom: string;
  doubleRoom: string;
  deluxeRoom: string;
  suitRoom: string;
  cityName: string;
}

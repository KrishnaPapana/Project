export interface PackageName {
  packageName: string;
  numberOfPackages: string;
}

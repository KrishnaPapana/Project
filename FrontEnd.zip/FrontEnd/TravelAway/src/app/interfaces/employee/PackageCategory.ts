export interface PackageCategory {
  categoryId: string;
  numberOfPackages: string;
}

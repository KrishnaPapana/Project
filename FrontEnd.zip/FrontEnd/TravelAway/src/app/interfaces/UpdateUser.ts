export interface UpdateUser {
  FirstName: string;
  LastName: string;
  EmailId: string;
  Gender: string;
  ContactNo: string;
  DateOfBirth: Date;
  Address: string;
}

export interface GetUser {
  firstName: string;
  lastName: string;
  gender: string;
  contactNo: string;
  dateOfBirth: Date;
  address: string;
}

export interface AllPackages {
  packageName: string;
  description: string;
  international: boolean;
}

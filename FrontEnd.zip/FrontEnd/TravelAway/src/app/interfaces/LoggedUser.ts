export interface LoggedUser {
  firstName: string;
  lastName: string;
  roleId: number;
  gender: string;
  contactNo: string;
  dateOfBirth: Date;
  address: string;
}

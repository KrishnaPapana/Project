import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { BookPackage } from '../interfaces/customer/BookPackage'
import { Payment } from '../interfaces/customer/Payment';
import { Rating } from '../interfaces/customer/Rating';
import { CustomerCare } from '../interfaces/customer/CustomerCare';
import { AllPackages } from '../interfaces/AllPackage';
import { SubPackage } from '../interfaces/customer/SubPackage';
import { Accomodation } from '../interfaces/customer/Accomodation';
import { PaymentDetails } from '../interfaces/customer/GetPaymentDetails';
import { BookAccommodation } from '../interfaces/customer/AddAccommodation';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }


  bookPackage(contactNo: string, address: string, travelDate: Date, adults: string, children: string): Observable<string> {
    let mail = sessionStorage.getItem('email');
    let id = sessionStorage.getItem('packageId');
    let bookPackageObj: BookPackage
    bookPackageObj = { EmailId: mail, ContactNo: contactNo, Address: address, DateOfTravel: travelDate, NoOfChildren: Number(children), NoOfAdult: Number(adults), AccomodationId: "A100", PackageId: id }
    console.log(bookPackageObj)
    let tmp = this.http.post<string>('https://localhost:44396/api/TravelAway/AddBookingDetails', bookPackageObj).pipe(catchError(this.errorHandler))
    console.log(tmp)
    return tmp;
  }

  payment(): Observable<string> {
    let bookingId = sessionStorage.getItem('bookingId');
    let accomodationId = sessionStorage.getItem('accomodationId');
    //const params1 = new HttpParams().append('BookingId', sessionStorage.getItem('bookingId'));
    //const params2 = new HttpParams().append('AccommodationId', sessionStorage.getItem('accomodationId'));
    return this.http.get<string>('https://localhost:44396/api/TravelAway/TotalCost?BookingId=' + bookingId + '&AccommodationId=' + accomodationId).pipe(catchError(this.errorHandler))
  }




  rating(stars: string, comment: string): Observable<boolean> {
    let ratingObj: Rating;
    ratingObj = { BookingId: sessionStorage.getItem('bookingId'), Stars: Number(stars), Comment: comment }
    console.log(ratingObj)
    return this.http.post<boolean>('https://localhost:44396/api/TravelAway/AddRating', ratingObj).pipe(catchError(this.errorHandler))
  }

  customerCare(question:string): Observable<boolean> {
    let customerCareObj: CustomerCare
    customerCareObj = { BookingId: sessionStorage.getItem('bookingId'), Status: 'In Progress', Question: question }
    console.log(customerCareObj)
    let tmp = this.http.post<boolean>('https://localhost:44396/api/TravelAway/AddQuery', customerCareObj).pipe(catchError(this.errorHandler))
    console.log(tmp)
    return tmp;
  }

  viewAllPackage(): Observable<AllPackages[]> {

    let tmp = this.http.get<AllPackages[]>('https://localhost:44396/api/TravelAway/GetAllPackages').pipe(catchError(this.errorHandler))
    console.log(tmp)
    return tmp;
  }
  getSubPackageDetails(packageName: string): Observable<SubPackage[]> {
    const params = new HttpParams().append('packageName', packageName);
    let tmp= this.http.get<SubPackage[]>('https://localhost:44396/api/TravelAway/GetSubPackageDetails', { params }).pipe(catchError(this.errorHandler))
    console.log(tmp)
    return tmp
  }

  getPackageByCategory(categoryId: string): Observable<AllPackages[]> {
    const params = new HttpParams().append('CategoryId', categoryId);
    let tmp = this.http.get<AllPackages[]>('https://localhost:44396/api/TravelAway/GetlPackagesByCategoryId', { params }).pipe(catchError(this.errorHandler))
    console.log(tmp)
    return tmp;
  }
  //accomodation function
  accomodation(): Observable<Accomodation[]> {
   
    return this.http.get<Accomodation[]>('https://localhost:44396/api/TravelAway/GetHotelDetails').pipe(catchError(this.errorHandler))
  }
  accomodation1() {
    let obj = [
      {
        hotelId: "H101",
        hotelName: "Sitakiran",
        cityName: "Bareilly",
        rating: 2,
        singleRoomPrice: 800,
        doubleRoomPrice: 1200,
        deluxeRoomPrice: 1500,
        suiteRoomPrice: 2000,
        accommodations: []
      },
      {
        hotelId: "H102",
        hotelName: "Taj",
        cityName: "Mumbai",
        rating: 5,
        singleRoomPrice: 10000,
        doubleRoomPrice: 15000,
        deluxeRoomPrice: 25000,
        suiteRoomPrice: 40000,
        accommodations: []
      }, {
        hotelId: "H103",
        hotelName: "Grand Continental",
        cityName: "Prayagraj",
        rating: 3,
        singleRoomPrice: 5000,
        doubleRoomPrice: 8000,
        deluxeRoomPrice: 12000,
        suiteRoomPrice: 18000,
        accommodations: []
      },
      {
        hotelId: "H104",
        hotelName: "Pancham",
        cityName: "Delhi",
        rating: 4,
        singleRoomPrice: 8000,
        doubleRoomPrice: 11000,
        deluxeRoomPrice: 15000,
        suiteRoomPrice: 25000,
        accommodations: []
      }

    ]
    return obj;
  }
  //post->accomodation details
  sendAccomodationDetails(hotelId: string, city: string, hotelName: string, hotelRating: string, hotelRoom: string, noOfRoom: Number, cost: Number): Observable<string> {
    //uncomment below line to hit the backend using post after mentioning the url
    let accObj: BookAccommodation;
    accObj = { BookingId: sessionStorage.getItem('bookingId'), HotelId: hotelId, HotelName: hotelName, CityName: city, Rating: Number(hotelRating), Cost: cost, RoomType: hotelRoom }

    console.log(accObj)
    let tmp = this.http.post<string>('https://localhost:44396/api/TravelAway/AddAccommodationDetails', accObj).pipe(catchError(this.errorHandler))
    //this.http.post<boolean>('', accmObj).pipe(catchError(this.errorHandler))
    return tmp
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'ERROR')

  } 
}

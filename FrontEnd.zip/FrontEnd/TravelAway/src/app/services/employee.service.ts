import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Vehicle } from '../interfaces/employee/Vehicle';
import { catchError } from 'rxjs/operators';
import { Hotel } from '../interfaces/employee/Hotel';
import { PackageCategory } from '../interfaces/employee/PackageCategory';
import { PackageName } from '../interfaces/employee/PackageName';
import { PackageMonth } from '../interfaces/employee/PackageMonth';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  addVehicle(name: string, type: string, pricePerHr: string, pricePerKm: string): Observable<boolean> {
    let vehicleObj: Vehicle

    vehicleObj = { vehicleName: name, vehicleType: type, pricePerHr: pricePerHr, pricePerKm: pricePerKm }
    console.log(vehicleObj)
    return this.http.post<boolean>('https://localhost:44396/api/TravelAway/ValidateUser', vehicleObj).pipe(catchError(this.errorHandler))
    
  }

  addHotel(name: string, rating: string, single: string, double: string, deluxe: string, suit: string, city: string): Observable<boolean> {

    let hotelObj: Hotel

    hotelObj = { hotelName: name, hotelRating: rating, singleRoom: single, doubleRoom: double, deluxeRoom: deluxe, suitRoom: suit, cityName: city }
    console.log(hotelObj)
    return this.http.post<boolean>('', hotelObj).pipe(catchError(this.errorHandler))
  }

  getReportByPackageCategory(): Observable<PackageCategory[]> {

    return this.http.get<PackageCategory[]>('https://localhost:44396/api/TravelAway/ReportByCategory').pipe(catchError(this.errorHandler))

  }

  getReportByPackageName(): Observable<PackageName[]> {
    return this.http.get<PackageName[]>('https://localhost:44396/api/TravelAway/ReportByPackageName').pipe(catchError(this.errorHandler))
  }

  getReportByMonth(): Observable<PackageMonth[]> {
    return this.http.get<PackageMonth[]>('https://localhost:44396/api/TravelAway/ReportByMonth').pipe(catchError(this.errorHandler))
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'ERROR')

  } 
}

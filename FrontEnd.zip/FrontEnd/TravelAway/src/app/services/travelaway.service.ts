import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User, } from '../interfaces/User';
import { UpdateUser } from '../interfaces/UpdateUser';
import { LoginUser } from '../interfaces/LoginUser';
import { LoggedUser } from '../interfaces/LoggedUser';
import { GetUser } from '../interfaces/GetUser';

@Injectable({
  providedIn: 'root'
})
export class TravelawayService {
  fname: string;
    lname: string;

  constructor(private http: HttpClient) { }

  addUser(firstName: string, lastName: string, contactNumber: number, emailId: string, gender: string, dob: Date, address: string, password: string): Observable<boolean> {

    let userObj: User;
    userObj = { FirstName: firstName, LastName: lastName, EmailId: emailId, Gender: gender, DateOfBirth: dob, Address: address, ContactNo: contactNumber, UserPassword: password };
    console.log(userObj)
    let temp = this.http.post<boolean>('https://localhost:44396/api/TravelAway/AddUserDetails', userObj).pipe(catchError(this.errorHandler));
    return temp;

  }

  updateUser(firstName: string, lastName: string, contactNumber: string, emailId: string, gender: string, dob: Date, address: string): Observable<boolean> {

    let userObj: UpdateUser;
    userObj = { FirstName: firstName, LastName: lastName, EmailId: emailId, Gender: gender, DateOfBirth: dob, Address: address, ContactNo: contactNumber };
    console.log(userObj)
    let updateTemp = this.http.put<boolean>('https://localhost:44396/api/TravelAway/UpdateUserDetails', userObj).pipe(catchError(this.errorHandler));

    return updateTemp;
  }

  login(emailId: string, password: string): Observable<LoggedUser> {
    let LoginObj: LoginUser;
    LoginObj = { EmailId: emailId, Password: password }
    console.log(LoginObj)
    let tmp = this.http.post<LoggedUser>('https://localhost:44396/api/TravelAway/ValidateUser', LoginObj).pipe(catchError(this.errorHandler));
    console.log(tmp)
    return tmp;
  }
  setUpdatedName(firstName: string, lastName: string) {
    console.log("service")
    this.fname = firstName;
    this.lname = lastName
  }

  getUpdatedName() {
    return { firstName: this.fname, lastName: this.lname }
  }
  getDetails(emailId: string): Observable<GetUser> {

    const params = new HttpParams().append('emailId', emailId);
    let tmp = this.http.get<GetUser>('https://localhost:44396/api/TravelAway/GetUserDetails', { params }).pipe(catchError(this.errorHandler));
    console.log(tmp);
    return tmp;
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || 'ERROR')

  } 
}

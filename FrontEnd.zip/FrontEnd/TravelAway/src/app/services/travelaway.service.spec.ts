import { TestBed } from '@angular/core/testing';

import { TravelawayService } from './travelaway.service';

describe('TravelawayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TravelawayService = TestBed.get(TravelawayService);
    expect(service).toBeTruthy();
  });
});

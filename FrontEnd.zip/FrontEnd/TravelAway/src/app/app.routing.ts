import { RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { CreateUserComponent } from './components/create-user/create-user.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { UpdateUserComponent } from './components/update-user/update-user.component';
import { AddVehicleComponent } from './components/add-vehicle/add-vehicle.component';
import { AddHotelComponent } from './components/add-hotel/add-hotel.component';
import { GenerateReportComponent } from './components/generate-report/generate-report.component';
import { BookPackageComponent } from './components/book-package/book-package.component';
import { PaymentComponent } from './components/payment/payment.component';
import { SelectAccomodationComponent } from './components/select-accomodation/select-accomodation.component';
import { RatingComponent } from './components/rating/rating.component';
import { CustomerCareComponent } from './components/customer-care/customer-care.component';
import { BookVehicleComponent } from './components/book-vehicle/book-vehicle.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ViewAllPackagesComponent } from './components/view-all-packages/view-all-packages.component';
import { PackageDetailsComponent } from './components/package-details/package-details.component';

export var routing = RouterModule.forRoot([
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'addUser',  component: CreateUserComponent },
  { path: 'addVehicle', component: AddVehicleComponent },
  { path: 'addHotel', component: AddHotelComponent },
  { path: 'getReport', component: GenerateReportComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'bookAccomodation', component: SelectAccomodationComponent },
  { path: 'rating', component: RatingComponent },
  { path: 'customerCare', component: CustomerCareComponent },
  { path: 'bookVehicle', component: BookVehicleComponent },
  { path: 'reg', component: RegistrationComponent },
  { path: 'updateUser/:firstName/:lastName/:contactNo/:address/:dateOfBirth/:gender', component: UpdateUserComponent },
  { path: 'bookPackage', component: BookPackageComponent },
  { path: 'viewPackage', component: ViewAllPackagesComponent },
  { path: "packageDetails/:packageName", component: PackageDetailsComponent },
  { path: '', component: HomeComponent },
  { path: '*', component: HomeComponent }


])

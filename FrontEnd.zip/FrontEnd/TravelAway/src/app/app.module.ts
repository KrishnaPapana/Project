import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { routing } from './app.routing';
import { TravelawayService } from './services/travelaway.service';
import { CreateUserComponent } from './components/create-user/create-user.component';
import { UpdateUserComponent } from './components/update-user/update-user.component';
import { ConfirmEqualValidatorDirective } from './shared/confirm-equal-validator.directive.';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { DatePipe } from '@angular/common';
import { AddVehicleComponent } from './components/add-vehicle/add-vehicle.component';
import { AddHotelComponent } from './components/add-hotel/add-hotel.component';
import { GenerateReportComponent } from './components/generate-report/generate-report.component';
import { BookPackageComponent } from './components/book-package/book-package.component';
import { PaymentComponent } from './components/payment/payment.component';
import { SelectAccomodationComponent } from './components/select-accomodation/select-accomodation.component';
import { RatingComponent } from './components/rating/rating.component';
import { CustomerCareComponent } from './components/customer-care/customer-care.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { BookVehicleComponent } from './components/book-vehicle/book-vehicle.component';
import { ViewAllPackagesComponent } from './components/view-all-packages/view-all-packages.component';
import { PackageDetailsComponent } from './components/package-details/package-details.component';


@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    CreateUserComponent,
    UpdateUserComponent,
    ConfirmEqualValidatorDirective,
    LoginComponent,
    HomeComponent,
    AddVehicleComponent,
    AddHotelComponent,
    GenerateReportComponent,
    BookPackageComponent,
    PaymentComponent,
    SelectAccomodationComponent,
    RatingComponent,
    CustomerCareComponent,
    RegistrationComponent,
    BookVehicleComponent,
    ViewAllPackagesComponent,
    PackageDetailsComponent
  ],
  imports: [
    BrowserModule, routing, FormsModule, HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule, NgbModule, MatButtonModule, MatInputModule, MatIconModule, MatCardModule, MatFormFieldModule
  ],
  providers: [TravelawayService, HttpClientModule, DatePipe,NgbCarouselConfig ],
  bootstrap: [AppComponent]
})
export class AppModule { }

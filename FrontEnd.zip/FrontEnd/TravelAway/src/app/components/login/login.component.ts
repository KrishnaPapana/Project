import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { TravelawayService } from '../../services/travelaway.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private _travelawayservice: TravelawayService,
    private router: Router) {

  }
  errorMessage: string = "";
  successMessage: string = "";
  roleId: any;
  email = new FormControl('', [Validators.required, Validators.pattern(/^[a-z][a-z\.@$-A-Z0-9]*@[a-z]+\.[a-z]{2,4}$/)]);
  password = new FormControl('', [Validators.required]);

  register() {
    this.router.navigate(['/addUser']);
  }

  getErrorMessage(field: string) {
    if (field === 'email') {
      return this.email.hasError('required') ? 'Please enter your email' :
        this.email.hasError('pattern') ? 'Not a valid email' :
          '';
    } else if (field === 'password') {
      return this.password.hasError('required') ? 'Please enter your password' :
        '';
    }
  }


  ngOnInit() {

  }



  login() {
    //this.loginForm = {
    //  email: this.email.value,
    //  password: this.password.value
    //};
    this._travelawayservice.login(this.email.value, this.password.value).subscribe(
      (response) => {
        console.log("==>>", response)
        this.roleId = response.roleId;
        sessionStorage.setItem('roleId', this.roleId);
        sessionStorage.setItem('email', this.email.value)

        if (response.roleId == 1 || response.roleId == 2) {
          this.successMessage = "logged in successfully"
          sessionStorage.setItem('firstName', response.firstName);
          sessionStorage.setItem('lastName', response.lastName);

          location.reload();
          this.router.navigate(['/home']);
        }
        else if (response.roleId == -1 || response.roleId == 0) {
          alert("Enter Valid Credentials");
          this.router.navigate(['/login'])
        }
        else {
          alert("Error Please Try Again");
          this.router.navigate(['/login'])

        }



      },
      (errorResponse) => {
        this.errorMessage = errorResponse.message;
        this.errorMessage = "Please check your credentials"
        this.router.navigate(['/login']);
        sessionStorage.clear();
      }
    );
    this.router.navigate(['/home']);
  }

}

import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(private _customerService: CustomerService, private router: Router) { }
  model: any = {}
  response: any;
  ngOnInit() {
    this.model.contactNo = sessionStorage.getItem('bookingId')

    this._customerService.payment().subscribe(
      res => {
        this.response = res
        console.log(this.response)

        this.model.date = res
      },
      err => {
        alert("Error")
      },
      () => console.log("Payment Executed Successfully")
    )
    ////this.model.date = "1000"
  }

  pay() {

    alert("Payment Done")
    this.router.navigate(['rating'])
  }


}

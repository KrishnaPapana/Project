import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {

  currentRate: any;
  status: any;
  constructor(private _customerService: CustomerService, private router: Router) { }
  model: any = {}
  ngOnInit() {
  }

  rating() {
    this._customerService.rating(this.currentRate, this.model.comment).subscribe(
      res => {
        this.status = res
        if (this.status) {
          alert("Thank you for your time")
          this.router.navigate(['/'])
        }
        else {
          alert("Please try again")
          this.router.navigate(['/'])
        }
      },
      () => console.log("Rating Executed Successfully")
    )
    console.log(this.currentRate)
}

}

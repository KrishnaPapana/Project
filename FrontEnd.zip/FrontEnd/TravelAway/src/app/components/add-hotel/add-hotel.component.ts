import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-hotel',
  templateUrl: './add-hotel.component.html',
  styleUrls: ['./add-hotel.component.css']
})
export class AddHotelComponent implements OnInit {

  model: any = {}
  status: boolean = false;
  constructor(private _employeeServices: EmployeeService, private router: Router) { }

  ngOnInit() {
  }

  addHotel() {
    this._employeeServices.addHotel(this.model.hotelName, this.model.rating, this.model.single, this.model.double, this.model.deluxe, this.model.suit, this.model.cityName).subscribe(
      hotelResponse => {
        this.status = hotelResponse
        if (this.status) {
          alert("Hotel Added Successfully")
          this.router.navigate(['/home'])
        }
      },
      error => {
        alert("Error Occurred, Please Try Again")
        this.router.navigate(['/hom'])
      },
      () => console.log("Add Hotel Executed Sucessfully")

    )
    console.log(this.model)
  }

}

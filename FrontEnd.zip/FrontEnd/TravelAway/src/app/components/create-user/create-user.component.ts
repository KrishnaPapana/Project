import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TravelawayService } from '../../services/travelaway.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private _travelawayservice: TravelawayService, private router: Router) { }
  status: boolean

  ngOnInit() {

  }
  model: any = {};
  flag: boolean = false; 
  gFlag: boolean = false;
  sFlag: boolean = false;
  s2Flag: boolean = false;
  date = new Date();
  maxDate = (new Date().getFullYear()).toString() + "-0" + (new Date().getMonth() + 1).toString() + "-" + (new Date().getDate()-1).toString(); 
  checkPassword() {
    if (this.model.password != this.model.confirmPassword) {
      this.flag = true
    }
    else {
      this.flag = false
    }
  }
  checkGender() {
    if (this.model.gender.toLowerCase() === "male" || this.model.gender.toLowerCase() === "female") {
      this.gFlag = false
    }
    else {
      this.gFlag = true
    }
  }

  checkSpace1() {
    
    if ((this.model.firstName as string).indexOf(' ') >= 0) {
      this.sFlag = true;
    }
    else {
      this.sFlag = false;
    }
  }
  
  checkSpace2() {

    if ((this.model.lastName as string).indexOf(' ') >= 0) {
      this.s2Flag = true;
    }
    else {
      this.s2Flag = false;
    }
  }

  onSubmit() {
  }
  addUser() {
    if (this.model.gender.toLowerCase() == "male") {
      this.model.gender = 'M'
    } else {
      this.model.gender= 'F'
    }
    
    this._travelawayservice.addUser(this.model.firstName, this.model.lastName, this.model.contactNo, this.model.email, this.model.gender, this.model.dob, this.model.address, this.model.password).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          alert("Account Created Successfully");
        }
        else {
          alert("some error has occured")
          this.router.navigate(['/home'])
        }

        console.log(response)
        
        this.router.navigate(['/login'])
      },
      error => {
        //this.errorAddMsg = error;
        //this.msg = "some error occured";
        alert("Error Occurred plase try again");
        this.router.navigate(['/home'])
      },
      () => { console.log("Add customer completed"); }
    );

  }

  

}

import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-package-details',
  templateUrl: './package-details.component.html',
  styleUrls: ['./package-details.component.css']
})
export class PackageDetailsComponent implements OnInit {


  constructor(private _customerService: CustomerService, private router: Router, private aRoute: ActivatedRoute) { }
  allPackagearr: any[];
  packageData: any[] = [];
  packageName: string;
  image: string;
  packageId: string;
  ngOnInit() {

    //Response
    //[{ "packageName": "Amazon Jungle", "description": "Lorem Ipsum Dolor Siet ut labore et dolore magna aliqua. Ut enim ad minim veniam" }, { "packageName": "Argentina", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "Australia", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "Brazil", "description": "reprehenderit in voluptate velit esse cillum dolore eu\r\nfugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." }, { "packageName": "Indonesia", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "Jakarta", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "North-East India", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "Tibet", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "United Kingdom", "description": "Lorem Ipsum Dolor Siet" }, { "packageName": "Wuhan", "description": "Lorem Ipsum Dolor Siet" }]

    this._customerService.viewAllPackage().subscribe(
      res => {
        this.allPackagearr = res
      })
      this.aRoute.params.subscribe(
      (param) => { this.packageName = param.packageName; }
    )
    console.log(this.packageName)
    this.packageDetail();
  }

  packageDetail() {
    //response

    //[
    //  {
    //    "packageId": "P102",
    //    "packageName": "Amazon Jungle",
    //    "placesToVisit": "Lorem Ipsum",
    //    "subPackageDescription": "Lorem Ipsum Dolor Sie",
    //    "details": "3/4",
    //    "price": 52000,
    //    "packageNameNavigation": null,
    //    "bookPackage": []
    //  }
    //]

    this._customerService.getSubPackageDetails(this.packageName).subscribe(
      res => {
        console.log(res)
        this.packageData = res;
        console.log(this.packageData);
        
        
      }
    )
    //packArr = this.allPackagearr.filter((packSelected) => { return packSelected.name == this.packageName });
    this.image = "img1.jpg";
    
    //console.log("1111", packArr[0].packInfo)
    //for (let i = 0; i < packArr[0]['packInfo'].length; i++) {
    //  console.log("i", packArr[0]['packInfo'][i])
    //  this.packageData.push(packArr[0]['packInfo'][i]);

    //}
  }

  bookPackage(id: string) {
    console.log("gii")
    sessionStorage.setItem('packageId', id)
    this.router.navigate(['bookPackage']);
  }

}

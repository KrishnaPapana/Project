import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-view-all-packages',
  templateUrl: './view-all-packages.component.html',
  styleUrls: ['./view-all-packages.component.css']
})
export class ViewAllPackagesComponent implements OnInit {
  allFlag: boolean;
    errorFlag: boolean;

  constructor(private _customerService: CustomerService, private router: Router) { }

  packageArr: any = [];
  allPackageArr: any[];
  tmpPackageArr: any[];
  interFlag: boolean = false;
  domesFlag: boolean = false;
  interPackArr: any = [];
  domestPackArr: any = [];
  subCatPackArr: any = [];
  ngOnInit() {
    // this.custService.viewAllpackage().subscribe(
    //(res) => { this.allPackageArr = res },
    //(err) => { console.log("error occured") },
    //() => { console.log("completed") }
    //);

    this._customerService.viewAllPackage().subscribe(
      res => {
        this.allPackageArr = res
        this.packageArr = this.allPackageArr;
        this.tmpPackageArr = res
        for (let item of this.allPackageArr) {
          item.image = "img1.jpg"
        }
        console.log(this.allPackageArr)
      }
    )

    this.packageArr = this.allPackageArr

  }

  packageTypeInternational() {
    if (this.interFlag == false) {
      this.interFlag = true
      this.subCatPackArr = this.packageArr
      for (let i of this.packageArr) {
        if (i.international == true) {
          this.interPackArr.push(i)
          
        }
      }
      this.packageArr = this.interPackArr
    }
    else {
      this.interFlag = false
      if (this.domesFlag == true) {
        this.packageArr = this.domestPackArr
      }
      else {
        this.packageArr = this.subCatPackArr
      }
      this.packageArr = this.subCatPackArr
      
    }
    if ((this.domesFlag == true && this.interFlag == true) || (this.domesFlag == false && this.interFlag == false)) {
      
        console.log("both")
        this.packageArr = this.allPackageArr
        for (let item of this.packageArr) {
          item.image = "img1.jpg"
        }
      
    }
    console.log(this.interFlag)
  }


  packageTypeDomestic() {
    console.log("Hi")
    if (this.domesFlag == false) {
      this.domesFlag = true
      this.subCatPackArr = this.packageArr
      for (let i of this.packageArr) {
        if (i.international == false) {
          this.domestPackArr.push(i)

        }
      }
      this.packageArr = this.domestPackArr
    }
    else {
      this.domesFlag = false
      if (this.interFlag == true) {
        this.packageArr = this.interPackArr
      }
      else {
        this.packageArr = this.subCatPackArr
      }
      this.packageArr = this.subCatPackArr
      
    }
    if ((this.domesFlag == true && this.interFlag == true) || (this.domesFlag == false && this.interFlag == false)) {
      console.log("both")
      this.packageArr = this.allPackageArr
      for (let item of this.packageArr) {
        item.image = "img1.jpg"
      }
    }
    console.log(this.domesFlag)
  }

  packageType3() {
    this.allFlag = false;
    this.errorFlag = true;
    this.packageArr = []
  }


  packageSelected(category: string) {
    //let arr = [];
    if (category == "All") {
      this.allPackageArr = this.tmpPackageArr;
      this.packageArr = this.allPackageArr
      console.log("packageArr===>", this.packageArr)
    }
    else if (category == "Adventure") {
      this._customerService.getPackageByCategory("1").subscribe(
        res => {
          this.packageArr = res
          console.log(res)
          for (let item of this.packageArr) {
            item.image = "img1.jpg"
          }
        }
      )
      console.log("packageArr===>", this.packageArr)
    }

    else if (category == "Nature") {
      this._customerService.getPackageByCategory("3").subscribe(
        res => {
          this.packageArr = res

          for (let item of this.packageArr) {
            item.image = "img1.jpg"
          }
        }
      )
      console.log("packageArr===>", this.packageArr)
    }
    else if (category == "Cultural") {
      this._customerService.getPackageByCategory("4").subscribe(
        res => {
          this.packageArr = res
          for (let item of this.packageArr) {
            item.image = "img1.jpg"
          }
        }
      )
      console.log("packageArr===>", this.packageArr)
    }
    else if (category == "Spiritual") {
      this._customerService.getPackageByCategory("5").subscribe(
        res => {
          this.packageArr = res
          for (let item of this.packageArr) {
            item.image = "img1.jpg"
          }
        }
      )
      console.log("packageArr===>", this.packageArr)
    }
    else if (category == "Sports") {
      this._customerService.getPackageByCategory("2").subscribe(
        res => {
          this.packageArr = res
          for (let item of this.packageArr) {
            item.image = "img1.jpg"
          }
        }
      )
      console.log("packageArr===>", this.packageArr)
    }
  }

  packageDetail(packageName) {
    this.router.navigate(['packageDetails', packageName])
  }

}

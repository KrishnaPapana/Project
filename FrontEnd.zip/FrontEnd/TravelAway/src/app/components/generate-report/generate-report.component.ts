import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.css']
})
export class GenerateReportComponent implements OnInit {

  model: any = {}
  report1 = []
  report2 = []
  report3 = []
  constructor(private _employeeService: EmployeeService, private router: Router) { }

  ngOnInit() {
  }

  fetch() {
    console.log(this.model.report)
    if (this.model.report == 1) {
      console.log(this.model.report)
      this._employeeService.getReportByPackageCategory().subscribe(
        response => {
          console.log(response)
          this.report1 = response
          if (this.report1.length == 0) {
            alert("No Data Available")
            this.router.navigate(['/'])
          }
        },
        error => {
          alert("No report")
          this.router.navigate(['/'])

        },
        () => console.log("Executed Successfully")
      )
      this.report2 = []
      this.report3 = []
    }
    else if (this.model.report == 2) {
      
      this._employeeService.getReportByPackageName().subscribe(
        response => {
          this.report2 = response
          if (this.report2.length == 0) {
            alert("No Data Available")
            this.router.navigate(['/'])
          }
        },
        error => {
          alert("No report")
        },
        () => console.log("Executed Succesfully")

      )
      this.report1 = []
      this.report3 = []
    }
    else if (this.model.report == 3) {
      this._employeeService.getReportByMonth().subscribe(
        response => {
          this.report3 = response
          if (this.report3.length == 0) {
            alert("No Data Available")
            this.router.navigate(['/'])
          }
        },
        error => {
          alert("No report")
          this.router.navigate(['/'])
        },
        () => console.log("Executed Succesfully")
        
      )
      this.report1 = []
      this.report2 = []
    }
    
  }

}

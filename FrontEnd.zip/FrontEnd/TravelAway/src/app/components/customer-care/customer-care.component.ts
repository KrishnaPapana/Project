import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-care',
  templateUrl: './customer-care.component.html',
  styleUrls: ['./customer-care.component.css']
})
export class CustomerCareComponent implements OnInit {

  model: any = {}
  status: any
  constructor(private _customerService: CustomerService, private router: Router) { }

  ngOnInit() {
  }

  register() {
    this._customerService.customerCare(this.model.compalint).subscribe(
      res => {
        this.status = res
        if (this.status) {
          alert("Question registered Successfully, we will get back to you")
          this.router.navigate(['/'])
        }
        else {
          alert("Please Try again")
          this.router.navigate(['/'])
        }
      },
      err => {
        alert("Error, Try Again")
        this.router.navigate(['/'])
      },
      () => console.log("Customer Care Executed Sucessfully")

    )
  }

}

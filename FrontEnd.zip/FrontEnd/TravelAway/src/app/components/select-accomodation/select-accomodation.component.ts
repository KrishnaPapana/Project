import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { CustomerService } from '../../services/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-select-accomodation',
  templateUrl: './select-accomodation.component.html',
  styleUrls: ['./select-accomodation.component.css']
})
export class SelectAccomodationComponent implements OnInit {

  constructor(private custService: CustomerService, private router: Router, private f: FormBuilder) { }

  accomodationObj: any;
  accmForm: FormGroup;
  bookingId: string;
  cityArr: string[] = [];
  hotelArr: any[];
  cost: number = 0;
  data: any = [];
  accommodatonId: string;


  ngOnInit() {
    //this.cityArr = this.accomodationObj.city;

    console.log(sessionStorage.getItem('bookingId'))
    this.getdata()
    
    //this.accomodationObj = this.custService.accomodation1();

    //this.data = this.accomodationObj
    console.log("data", this.data)

    this.bookingId = sessionStorage.getItem('bookingId')
    

    this.accmForm = this.f.group({
      city: ["", Validators.required],
      hotelName: ["", Validators.required],
      hotelRating: ["", Validators.required],
      hotelRoom: ["", Validators.required],
      noOfRoom: ["", Validators.required],
      bookingId: [{ value: this.bookingId, disabled: true }, Validators.required]

    });
  }

  getdata() {
    this.custService.accomodation().subscribe(
      res => {
        this.data = res
        console.log("sdf---", this.data)
        this.getCityArr()
        console.log(this.cityArr)
      },
      err => {
        alert("Error Occurred, Try Again Later")
        this.router.navigate(['/'])
      },
      () => console.log("executed succesfully")
    )
    
    
    
  }


  getCityArr() {
    console.log(this.data)
    for (let i of this.data) {
      this.cityArr.push(i.cityName)

    }
    this.cityArr = this.cityArr.filter((item, i, ar) => ar.indexOf(item) === i);
    console.log("cityArr--", this.cityArr)
  }

  hotelChange(city) {
    console.log("enter", city)

    this.hotelArr = this.data.filter((data) => { return data.cityName == city })
    console.log("hotel--", this.hotelArr)
  }



  calCost(noOfRoom, roomType) {
    let arr = this.hotelArr.filter((hotel) => { return hotel.hotelName == this.accmForm.value.hotelName })
    let roomcost;
    if (roomType == "singleRoom") {
      roomcost = arr[0].singleRoomPrice;
    } else if (roomType == "doubleRoom") {
      roomcost = arr[0].doubleRoomPrice;
    } else if (roomType == "deluxeRoom") {
      roomcost = arr[0].deluxeRoomPrice;
    } else {
      roomcost = arr[0].suiteRoomPrice;
    }

    this.cost = noOfRoom * roomcost
  }

  addDetails() {
    console.log("hii", this.accmForm.value)
    let hotelId
    for (let i of this.data) {
      if (i.hotelName == this.accmForm.value.hotelName) {
        hotelId = i.hotelId
      }
    }
    //sessionStorage.setItem('acc', this.cost.toString())
    //let res = this.custService.sendAccomodationDetails(this.accmForm.value);
    this.custService.sendAccomodationDetails(hotelId, this.accmForm.value.city, this.accmForm.value.hotelName, this.accmForm.value.hotelRating, this.accmForm.value.hotelRoom, this.accmForm.value.noOfRoom, this.cost).subscribe(
      res => {
        this.accommodatonId = res
        console.log(this.accommodatonId)
        if (this.accommodatonId == "null") {
          
          alert("Booking Unscessfull, Please try again")
          this.router.navigate(['/'])
        }
        else {
          sessionStorage.setItem('accomodationId', this.accommodatonId)
          let flag = confirm("Accomodation details added successfully.....want to continue for Payment?")
          if (flag) {
          this.router.navigate(['payment'])
          }
          else {
        //navigate to booking history page
          this.router.navigate(['/']);
          }
          //this.router.navigate(['payment'])

        }
      }

    )
    //let res = true
    //if (res) {
    //  let flag = confirm("Accomodation details added successfully.....want to continue for Payment?")
    //  if (flag) {
    //    this.router.navigate(['payment'])
    //  }
    //  else {
    //    //navigate to booking history page
    //    this.router.navigate(['/']);
    //  }
    //} else {
    //  alert("Accomodation booking failed....Try Again")
    //  this.router.navigate(['/']);
    //}
  }

  cancel() {
    this.router.navigate(['payment']);

  }

  getErrorMessage(field: string) {
    if (field === 'city') {
      return this.accmForm.controls['city'].hasError('required') ? 'You must choose city' : '';
    } else if (field === 'hotelName') {
      return this.accmForm.controls['hotelName'].hasError('required') ? 'You must choose hotel' : '';
    }
    else if (field === 'hotelRating') {
      return this.accmForm.controls['hotelRating'].hasError('required') ? 'You must choose hotel rating' : '';
    }
    else if (field == 'hotelRoom') {
      return this.accmForm.controls['hotelRoom'].hasError('required') ? 'You must select the desired Room' : '';
    }
    else {
      return this.accmForm.controls['noOfRoom'].hasError('required') ? 'You must enter the number of rooms you wanted' : ""
    };

  }
}

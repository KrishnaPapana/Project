import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectAccomodationComponent } from './select-accomodation.component';

describe('SelectAccomodationComponent', () => {
  let component: SelectAccomodationComponent;
  let fixture: ComponentFixture<SelectAccomodationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectAccomodationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectAccomodationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

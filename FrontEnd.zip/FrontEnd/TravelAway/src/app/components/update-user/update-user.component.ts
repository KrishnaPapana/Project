import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Data } from '@angular/router';
import { TravelawayService } from '../../services/travelaway.service';
import { FormBuilder } from '@angular/forms';
import { Injectable } from '@angular/core';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  firstName: string;
  lastName: string;
  emailId: string;
  gender: string;
  contactNo: string;
  dateOfBirth: Date;
  address: string;
  
  status: boolean;
  errorMsg: any;
  gFlag: boolean = false;
  date = new Date();
  maxDate = (new Date().getFullYear()).toString() + "-0" + (new Date().getMonth() + 1).toString() + "-" + (new Date().getDate() - 1).toString();
    s2Flag: boolean = false;
    sFlag: boolean = false;

  checkGender() {
    if (this.gender.toLowerCase() === "male" || this.gender.toLowerCase() === "female") {
      this.gFlag = false
    }
    else {
      this.gFlag = true
    }
  }

  checkSpace2() {

    if ((this.firstName as string).indexOf(' ') >= 0) {
      this.s2Flag = true;
    }
    else {
      this.s2Flag = false;
    }
  }

  checkSpace() {

    if ((this.lastName as string).indexOf(' ') >= 0) {
      this.sFlag = true;
    }
    else {
      this.sFlag = false;
    }
  }

  constructor(private route: ActivatedRoute, private _travelAwayService: TravelawayService, private router: Router) { }

  ngOnInit() {
    //this.emailId = sessionStorage.getItem("userName");
    this.emailId = sessionStorage.getItem("email");
    console.log("Hi")
    this.firstName = this.route.snapshot.params['firstName'];
    this.lastName = this.route.snapshot.params['lastName'];
    this.gender = this.route.snapshot.params['gender'];
    
    this.contactNo = this.route.snapshot.params['contactNo'];
    this.address = this.route.snapshot.params['address'];
    this.dateOfBirth = new Date(this.route.snapshot.params['dateOfBirth']);

    if (this.gender == "M") {
      this.gender = "Male"
    }
    else {
      this.gender = "Female"
    }
    //this.dateOfBirth = new Date(2019,2,2);
  }
  updateUser(firstname: string, lastname: string, emailid: string, Gender: string, contactno: string, date: Date, Address: string) {
    if (Gender.toLowerCase() == "male") {
      Gender = "M"
    }
    else {
      Gender = "F"
    }
    console.log(Gender)
    this._travelAwayService.updateUser(firstname,lastname, contactno, this.emailId, Gender, date, Address).subscribe(
      responseUpdateUserStatus => {
        this.status = responseUpdateUserStatus;
        if (this.status) {
          sessionStorage.setItem('firstName', firstname);
          sessionStorage.setItem('lastName', lastname);

          alert("User updated successfully.");
          this._travelAwayService.setUpdatedName(firstname, lastname);
          //location.reload();
          sessionStorage.setItem("ufirstName", firstname)

          this.router.navigate(['/home']);
        }
        else {
          alert("Some error occured, please try again.");
          this.router.navigate(['/home'])

        }
      },
      responseUpdateCartError => {
        this.errorMsg = responseUpdateCartError;
        console.log(this.errorMsg);
        alert("Some error occured, please try after some time.");
        this.router.navigate(['']);
      },
      () => console.log("UpdateUser method executed successfully.")
    );
  }
  }




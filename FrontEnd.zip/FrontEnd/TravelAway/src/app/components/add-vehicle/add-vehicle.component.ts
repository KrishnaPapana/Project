import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.css']
})
export class AddVehicleComponent implements OnInit {

  vehicles: string[] = ["Two Wheeler", "Four Wheeler", "Mini Bus"];
    status: boolean;


  constructor(private _employeeService: EmployeeService, private router: Router) { }
  
  model: any = {};
  ngOnInit() {
  }

  addVehicle() {
    console.log(this.model)
    this._employeeService.addVehicle(this.model.name, this.model.type, this.model.pricePerKm, this.model.pricePerHr).subscribe(
      vehicleResponse => {
        this.status = vehicleResponse;
        if (this.status) {
          alert("Hotel Succesfully Added");
          this.router.navigate(['/home']);
        }
        else {
          alert("Error Try Again");
          this.router.navigate(['/home']);
        }
      },
      error => {

      },
      () => console.log("Add Vehicle Executed Successfully")
    )
  }

}

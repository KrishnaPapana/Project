import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Route, Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-book-package',
  templateUrl: './book-package.component.html',
  styleUrls: ['./book-package.component.css']
})
export class BookPackageComponent implements OnInit {

  model: any = {}
  minDate = (new Date().getFullYear()).toString() + "-0" + (new Date().getMonth() + 1).toString() + "-" + (new Date().getDate() + 1).toString();
  bookingId: string;
  children: string = "0"
  packageId: string
  constructor(private _customerService: CustomerService, private router: Router, private route: ActivatedRoute) { }
  childrenVal(e) {
    this.children = e.target.value
    console.log(e.target.value)
  }
  ngOnInit() {
    //this.packageId = this.route.snapshot.params['packageId'];
    console.log(sessionStorage.getItem('packageId'))
  }
  book() {
    console.log(this.children)
    console.log(this.model)
    this._customerService.bookPackage(this.model.contactNo, this.model.address, this.model.date, this.model.adults, this.children).subscribe(
      res => {
        this.bookingId = res;
        if (this.bookingId == "null") {


          alert("Booking Unscessfull, Please try again")
          this.router.navigate(['/'])

          //this.router.navigate(['bookPackage'])
        }
        else {

          sessionStorage.setItem('bookingId', this.bookingId)
          sessionStorage.setItem('accomodationId', "A100")
          let flag = confirm("Package Booked Successfully.....want to continue for Accomodation?")
          console.log(flag)

          if (flag) {
            this.router.navigate(['bookAccomodation'])
          }
          else {
            this.router.navigate(['payment'])
          }
        }
      },
      err => {
        alert("Error Occurred, Please try again")
        this.router.navigate(['/'])

      },
      () => console.log("Add Package Executed Successfully")

    )

  }

}

import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravelawayService } from './services/travelaway.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'TravelAway';
  firstName: string = '';
  lastName: string = '';
  loggedUser: boolean = false;
  loggedEmail: boolean = false;
  roleId: any;
  roleIdcheck: boolean = false;

  updateFlag: boolean = false;
  ufirstName: string;
  ulastName: string;
  ugender: string;
  ucontactNo: string;
  udob: string;
  uaddress: string;

  constructor(private router: Router, private _travelAwayServic: TravelawayService) { }

  ngOnInit() {
    this.firstName = sessionStorage.getItem("firstName");
    this.lastName = sessionStorage.getItem("lastName");
    console.log("firstname", this.firstName)
    console.log("lastname", this.lastName)
    if (this.firstName && this.lastName) {
      this.loggedUser = true;
      this.loggedEmail = true;
    }
    else {
      this.loggedUser = false;
      this.loggedEmail = false;
    }
    this.nameUpdate()
    this.roleIdValidate()
    //this.nameUpdate()

  }

  ngDoCheck() {

    this.nameUpdate()


  }

  signIn() {
    //this.loggedEmail = true;
    this.router.navigate(['/login']);
  }


  logout() {
    sessionStorage.clear();
    this.loggedEmail = false;
    this.loggedUser = false;
    this.roleIdcheck = false;
    this.router.navigate(['/']);
  }

  roleIdValidate() {
    this.roleId = sessionStorage.getItem("roleId");
    //this.roleId = "2";
    if (this.loggedEmail && this.roleId == 2) {
      this.roleIdcheck = true;
    }
    else {
      this.roleIdcheck = false;
    }


  }

  updateUser() {

    console.log(sessionStorage.getItem('email'))
    this._travelAwayServic.getDetails(sessionStorage.getItem('email')).subscribe(
      response => {
        console.log(response)
        this.uaddress = response[0].address
        this.ucontactNo = response[0].contactNo
        this.udob = <string>response[0].dateOfBirth
        this.ugender = response[0].gender
        this.ufirstName = response[0].firstName
        this.ulastName = response[0].lastName
        this.updateFlag = true;

        //sessionStorage.setItem("firstName", this.ufirstName);
        //this.firstName = this.ufirstName

        //this.nameUpdate()

        //this.router.navigate(['/updateUser', this.firstName, this.lastName, this.contactNo, this.address, this.dob, this.gender])
        this.router.navigate(['/updateUser', this.ufirstName, this.ulastName, this.ucontactNo, this.uaddress, this.udob, this.ugender])
      },
      err => {
        alert("Error");
        this.router.navigate(['/home'])
      }

    )

  }

  nameUpdate() {
    if (this.updateFlag) {
      console.log("123")
      this.firstName = sessionStorage.getItem("firstName");
      this.lastName = sessionStorage.getItem("lastName");
      let res = this._travelAwayServic.getUpdatedName();
      console.log("res", res)
      this.firstName = res.firstName;
      this.lastName = res.lastName;
    }
    else {
      this.firstName = sessionStorage.getItem("firstName");
      this.lastName = sessionStorage.getItem("lastName");


    }

  }

}

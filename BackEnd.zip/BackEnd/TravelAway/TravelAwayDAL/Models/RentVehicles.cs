﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class RentVehicles
    {
        public int RentVehicleId { get; set; }
        public int? VehicleId { get; set; }
        public string VehicleType { get; set; }
        public DateTime RentDate { get; set; }
        public TimeSpan PickupTime { get; set; }
        public decimal? NoOfHours { get; set; }
        public decimal? NoOfKm { get; set; }
        public decimal Amount { get; set; }

        public virtual Vehicles Vehicle { get; set; }
    }
}

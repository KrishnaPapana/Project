﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Hotels
    {
        public Hotels()
        {
            Accommodations = new HashSet<Accommodations>();
        }

        public string HotelId { get; set; }
        public string HotelName { get; set; }
        public string CityName { get; set; }
        public byte Rating { get; set; }
        public decimal SingleRoomPrice { get; set; }
        public decimal DoubleRoomPrice { get; set; }
        public decimal DeluxeRoomPrice { get; set; }
        public decimal SuiteRoomPrice { get; set; }

        public virtual ICollection<Accommodations> Accommodations { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Accommodations
    {
        public Accommodations()
        {
            BookPackage = new HashSet<BookPackage>();
        }

        public string AccommodationId { get; set; }
        public string HotelId { get; set; }
        public string HotelName { get; set; }
        public string CityName { get; set; }
        public byte Rating { get; set; }
        public string RoomType { get; set; }
        public decimal Cost { get; set; }

        public virtual Hotels Hotel { get; set; }
        public virtual ICollection<BookPackage> BookPackage { get; set; }
    }
}

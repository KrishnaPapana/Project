﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class SubPackageDetails
    {
        public SubPackageDetails()
        {
            BookPackage = new HashSet<BookPackage>();
        }

        public string PackageId { get; set; }
        public string PackageName { get; set; }
        public string PlacesToVisit { get; set; }
        public string SubPackageDescription { get; set; }
        public string Details { get; set; }
        public decimal Price { get; set; }

        public virtual Packages PackageNameNavigation { get; set; }
        public virtual ICollection<BookPackage> BookPackage { get; set; }
    }
}

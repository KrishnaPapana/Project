﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TravelAwayDAL.Models
{
    public class PackagesDetails
    {
        [Key]
        public string PackageName { get; set; }
        public string Description { get; set; }

        public bool International { get; set; }
    }
}

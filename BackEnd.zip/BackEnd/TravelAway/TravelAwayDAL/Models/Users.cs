﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Users
    {
        public Users()
        {
            BookPackage = new HashSet<BookPackage>();
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }
        public string Gender { get; set; }
        public string ContactNo { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }

        public virtual Roles Role { get; set; }
        public virtual ICollection<BookPackage> BookPackage { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class BookPackage
    {
        public string BookingId { get; set; }
        public string AccommodationId { get; set; }
        public string EmailId { get; set; }
        public string PackageId { get; set; }
        public string ContactNo { get; set; }
        public string Address { get; set; }
        public DateTime DateOfTravel { get; set; }
        public byte NoOfAdult { get; set; }
        public byte NoOfChildren { get; set; }
        public DateTime DateOfBooking { get; set; }

        public virtual Accommodations Accommodation { get; set; }
        public virtual Users Email { get; set; }
        public virtual SubPackageDetails Package { get; set; }
    }
}

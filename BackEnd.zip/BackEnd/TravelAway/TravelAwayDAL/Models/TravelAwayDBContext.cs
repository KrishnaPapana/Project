﻿using Microsoft.EntityFrameworkCore;

namespace TravelAwayDAL.Models
{
    public partial class TravelAwayDBContext : DbContext
    {
        public TravelAwayDBContext()
        {
        }

        public TravelAwayDBContext(DbContextOptions<TravelAwayDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Accommodations> Accommodations { get; set; }
        public virtual DbSet<BookPackage> BookPackage { get; set; }
        public virtual DbSet<Categories> Categories { get; set; }
        public virtual DbSet<CustomerCare> CustomerCare { get; set; }
        public virtual DbSet<Hotels> Hotels { get; set; }
        public virtual DbSet<Packages> Packages { get; set; }
        public virtual DbSet<Ratings> Ratings { get; set; }
        public virtual DbSet<RentVehicles> RentVehicles { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<SubPackageDetails> SubPackageDetails { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<Vehicles> Vehicles { get; set; }

        public DbSet<AbstractUser> AbstractUser { get; set; }
        public virtual DbSet<ReportByCategory> ReportByCategory { get; set; }
        public DbSet<ReportByPackageName> ReportByPackageName { get; set; }
        public DbSet<ReportByMonth> ReportByMonth { get; set; }
        public DbSet<PackagesDetails> PackagesDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source =(localdb)\\MSSQLLocalDB;Initial Catalog=TravelAwayDB;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.ValidateUserCredentials(default(string), default(string)));
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.GenerateNewBookingId());
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.GenerateNewHotelId());
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.GenerateNewAccommodationId());
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.GenerateNewPackageId());
            modelBuilder.HasDbFunction(() => TravelAwayDBContext.CalculateTotalCost(default(string), default(string)));

            modelBuilder.Entity<Accommodations>(entity =>
            {
                entity.HasKey(e => e.AccommodationId)
                    .HasName("pk_AccommodationId");

                entity.Property(e => e.AccommodationId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CityName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Cost).HasColumnType("numeric(8, 0)");

                entity.Property(e => e.HotelId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.HotelName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.RoomType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Hotel)
                    .WithMany(p => p.Accommodations)
                    .HasForeignKey(d => d.HotelId)
                    .HasConstraintName("fk_HotelId");
            });

            modelBuilder.Entity<BookPackage>(entity =>
            {
                entity.HasKey(e => e.BookingId)
                    .HasName("pk_BookingId");

                entity.Property(e => e.BookingId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AccommodationId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ContactNo)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfBooking)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateOfTravel).HasColumnType("date");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PackageId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.HasOne(d => d.Accommodation)
                    .WithMany(p => p.BookPackage)
                    .HasForeignKey(d => d.AccommodationId)
                    .HasConstraintName("fk_AccommodationId");

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.BookPackage)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmailId");

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.BookPackage)
                    .HasForeignKey(d => d.PackageId)
                    .HasConstraintName("fk_PackageId");
            });

            modelBuilder.Entity<Categories>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("pk_CategoryId");

                entity.HasIndex(e => e.CategoryName)
                    .HasName("uq_CategoryName")
                    .IsUnique();

                entity.Property(e => e.CategoryId).ValueGeneratedOnAdd();

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CustomerCare>(entity =>
            {
                entity.HasKey(e => e.QueryId)
                    .HasName("pk_QueryId");

                entity.HasIndex(e => e.BookingId)
                    .HasName("uq_BookingId")
                    .IsUnique();

                entity.Property(e => e.Answer)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.BookingId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Query)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Hotels>(entity =>
            {
                entity.HasKey(e => e.HotelId)
                    .HasName("pk_HotelId");

                entity.Property(e => e.HotelId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CityName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DeluxeRoomPrice).HasColumnType("numeric(8, 0)");

                entity.Property(e => e.DoubleRoomPrice).HasColumnType("numeric(8, 0)");

                entity.Property(e => e.HotelName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.SingleRoomPrice).HasColumnType("numeric(8, 0)");

                entity.Property(e => e.SuiteRoomPrice).HasColumnType("numeric(8, 0)");
            });

            modelBuilder.Entity<Packages>(entity =>
            {
                entity.HasKey(e => e.PackageName)
                    .HasName("pk_PackageName");

                entity.Property(e => e.PackageName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Packages)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("fk_CategoryId");
            });

            modelBuilder.Entity<Ratings>(entity =>
            {
                entity.HasKey(e => e.RatingId)
                    .HasName("pk_RatingId");

                entity.Property(e => e.BookingId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Comment)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RentVehicles>(entity =>
            {
                entity.HasKey(e => e.RentVehicleId)
                    .HasName("pk_RentVehicleId");

                entity.Property(e => e.Amount).HasColumnType("numeric(5, 0)");

                entity.Property(e => e.NoOfHours).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.NoOfKm).HasColumnType("numeric(4, 0)");

                entity.Property(e => e.RentDate).HasColumnType("date");

                entity.Property(e => e.VehicleType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Vehicle)
                    .WithMany(p => p.RentVehicles)
                    .HasForeignKey(d => d.VehicleId)
                    .HasConstraintName("fk_VehicleId");
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("pk_RoleId");

                entity.HasIndex(e => e.RoleName)
                    .HasName("uq_RoleName")
                    .IsUnique();

                entity.Property(e => e.RoleId).ValueGeneratedOnAdd();

                entity.Property(e => e.RoleName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SubPackageDetails>(entity =>
            {
                entity.HasKey(e => e.PackageId)
                    .HasName("pk_PackageId");

                entity.Property(e => e.PackageId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Details)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.PackageName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlacesToVisit)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Price).HasColumnType("numeric(8, 0)");

                entity.Property(e => e.SubPackageDescription)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.PackageNameNavigation)
                    .WithMany(p => p.SubPackageDetails)
                    .HasForeignKey(d => d.PackageName)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_PackageName");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.EmailId)
                    .HasName("pk_EmailId");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ContactNo)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("fk_RoleId");
            });

            modelBuilder.Entity<Vehicles>(entity =>
            {
                entity.HasKey(e => e.VehicleId)
                    .HasName("pk_PurchaseId");

                entity.Property(e => e.RatePerHour).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.RatePerKm).HasColumnType("numeric(3, 0)");

                entity.Property(e => e.VehicleName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        [DbFunction("ufn_ValidateUserCredentials", "dbo")]
        public static int ValidateUserCredentials(string emailId, string password)
        {
            return 0;
        }
         [DbFunction("ufn_GenerateNewBookingId", "dbo")]
        public static string GenerateNewBookingId()
        {
            return null;
        }
         [DbFunction("ufn_GenerateNewAccommodationId", "dbo")]
        public static string GenerateNewAccommodationId()
        {
            return null;
        }
         [DbFunction("ufn_GenerateNewHotelId", "dbo")]
        public static string GenerateNewHotelId()
        {
            return null;
        }
         [DbFunction("ufn_GenerateNewPackageId", "dbo")]
        public static string GenerateNewPackageId()
        {
            return null;
        }
        [DbFunction("ufn_TotalCost", "dbo")]
        public static int CalculateTotalCost(string BookingId, string AccommodationId)
        {
            return 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Packages
    {
        public Packages()
        {
            SubPackageDetails = new HashSet<SubPackageDetails>();
        }

        public string PackageName { get; set; }
        public string Description { get; set; }
        public byte? CategoryId { get; set; }

        public bool International { get; set; }

        public virtual Categories Category { get; set; }
        public virtual ICollection<SubPackageDetails> SubPackageDetails { get; set; }
    }
}

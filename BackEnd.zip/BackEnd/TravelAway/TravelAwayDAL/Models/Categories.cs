﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Categories
    {
        public Categories()
        {
            Packages = new HashSet<Packages>();
        }

        public byte CategoryId { get; set; }
        public string CategoryName { get; set; }

        public virtual ICollection<Packages> Packages { get; set; }
    }
}

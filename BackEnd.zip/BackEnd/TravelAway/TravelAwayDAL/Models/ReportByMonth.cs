﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TravelAwayDAL.Models
{
    public class ReportByMonth
    {
        [Key]
        public int Month { get; set; }
        public int NumberOfBooking { get; set; }
    }
}

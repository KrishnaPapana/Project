﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class CustomerCare
    {
        public int QueryId { get; set; }
        public string BookingId { get; set; }
        public string Status { get; set; }
        public string Query { get; set; }
        public string Answer { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TravelAwayDAL.Models
{
    public class ReportByPackageName
    {
        [Key]
        public string PackageName { get; set; }
        public int NumberOfPackages { get; set; }
    }
}

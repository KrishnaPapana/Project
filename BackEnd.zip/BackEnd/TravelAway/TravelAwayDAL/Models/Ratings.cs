﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Ratings
    {
        public int RatingId { get; set; }
        public string BookingId { get; set; }
        public byte? Stars { get; set; }
        public string Comment { get; set; }
    }
}

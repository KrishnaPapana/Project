﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TravelAwayDAL.Models
{
    public class ReportByCategory
    {
        [Key]
        public byte CategoryId { get; set; }
        public int NumberOfPackages { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace TravelAwayDAL.Models
{
    public partial class Vehicles
    {
        public Vehicles()
        {
            RentVehicles = new HashSet<RentVehicles>();
        }

        public int VehicleId { get; set; }
        public string VehicleName { get; set; }
        public string VehicleType { get; set; }
        public decimal? RatePerHour { get; set; }
        public decimal? RatePerKm { get; set; }

        public virtual ICollection<RentVehicles> RentVehicles { get; set; }
    }
}

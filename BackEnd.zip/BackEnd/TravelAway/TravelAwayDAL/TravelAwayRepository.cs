﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using TravelAwayDAL.Models;


namespace TravelAwayDAL
{
    public class TravelAwayRepository
    {
        TravelAwayDBContext context;

        public TravelAwayRepository()
        {
            context = new TravelAwayDBContext();
        }

        public List<AbstractUser> GetUserDetails(string EmailId)
        {
            List<AbstractUser> abstractUser = null;
            try
            {
                SqlParameter prmEmailId = new SqlParameter("@EmailId", EmailId);
                Console.WriteLine("1");

                abstractUser = context.AbstractUser.FromSqlRaw("SELECT * FROM ufn_GetUserDetails(@EmailId)",
                                                         prmEmailId).ToList();
                Console.WriteLine("2--" + abstractUser.Count);

                foreach (AbstractUser i in abstractUser)
                {
                    Console.WriteLine("---" + i.FirstName);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return abstractUser;
        }

        public List<ReportByCategory> GetReportByCategories()
        {
            List<ReportByCategory> reports = null;
            try
            {
                Console.WriteLine("1");

                reports = context.ReportByCategory.FromSqlRaw("SELECT * FROM ufn_GenerateReportsByCategoryId()"
                                                        ).ToList();
                Console.WriteLine("2--" );

                
            }
            catch (Exception ex)
            {
                throw;
            }
            return reports;
        }

        public List<ReportByPackageName> GetReportByPackageName()
        {
            List<ReportByPackageName> reports = null;
            try
            {
                Console.WriteLine("1");

                reports = context.ReportByPackageName.FromSqlRaw("SELECT * FROM ufn_GenerateReportsByPackageName()"
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return reports;
        }


        public List<ReportByMonth> GetReportByMonth()
        {
            List<ReportByMonth> reports = null;
            try
            {
                Console.WriteLine("1");

                reports = context.ReportByMonth.FromSqlRaw("SELECT * FROM ufn_GenerateReportsByMonth()"
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return reports;
        }

        public int AddUserDetailsUsingUSP(string FirstName, string LastName, string EmailId, string UserPassword, string Gender, string ContactNo, DateTime DateOfBirth, string Address)
        {
            int result = -1;
            int returnResult = 0;
            SqlParameter prmFirstName = new SqlParameter("@FirstName", FirstName);
            SqlParameter prmLastName = new SqlParameter("@LastName", LastName);
            SqlParameter prmEmailId = new SqlParameter("@EmailId", EmailId);
            SqlParameter prmUserPassword = new SqlParameter("@UserPassword", UserPassword);
            SqlParameter prmGender = new SqlParameter("@Gender", Gender);
            SqlParameter prmContactNo = new SqlParameter("@ContactNo", ContactNo);
            SqlParameter prmDateOfBirth = new SqlParameter("@DateOfBirth", DateOfBirth);
            SqlParameter prmAddress = new SqlParameter("@Address", Address);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;

            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_RegisterUser @UserPassword,@Gender ,@EmailId,@DateOfBirth,@ContactNo,@Address,@FirstName,@LastName",
                                              prmReturnResult, prmUserPassword, prmGender, prmEmailId, prmDateOfBirth, prmContactNo, prmAddress, prmFirstName, prmLastName);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return returnResult;
        }

        public int EditUserDetailsUsingUSP(string FirstName, string LastName, string EmailId, string Gender, string ContactNo, DateTime DateOfBirth, string Address)
        {
            int result = -1;
            int returnResult = 0;
            SqlParameter prmFirstName = new SqlParameter("@FirstName", FirstName);
            SqlParameter prmLastName = new SqlParameter("@LastName", LastName);
            SqlParameter prmEmailId = new SqlParameter("@EmailId", EmailId);
            SqlParameter prmGender = new SqlParameter("@Gender", Gender);
            SqlParameter prmContactNo = new SqlParameter("@ContactNo", ContactNo);
            SqlParameter prmDateOfBirth = new SqlParameter("@DateOfBirth", DateOfBirth);
            SqlParameter prmAddress = new SqlParameter("@Address", Address);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;

            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_UpdateUser @Gender,@ContactNo ,@EmailId,@DateOfBirth,@Address,@FirstName,@LastName",
                                              prmReturnResult, prmGender, prmContactNo, prmEmailId, prmDateOfBirth, prmAddress, prmFirstName, prmLastName);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {

                result = -99;
                returnResult = -99;
            }
            return returnResult;
        }

        public int ValidateUser(string emailId, string password)
        {
            int RoleId = 0;
            try
            {
                RoleId = ((from s in context.Users
                           select TravelAwayDBContext.ValidateUserCredentials(emailId, password))
                             .FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return RoleId;
            }
            return RoleId;
        }


        //                          ********************************************
        //                          ********************************************
        //                          ********************************************
        //                                        Sprint 2
        //                          ********************************************
        //                          ********************************************
        //                          ********************************************



        public string GenrateBookingId()
        {
            string BookingId = null;
            try
            {
                BookingId = ((from s in context.Users
                              select TravelAwayDBContext.GenerateNewBookingId()).FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return BookingId;
            }
            return BookingId;
        }
         public string GenerateAccommodationId()
        {
            string BookingId = null;
            try
            {
                BookingId = ((from s in context.Users
                              select TravelAwayDBContext.GenerateNewAccommodationId()).FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return BookingId;
            }
            return BookingId;
        }
         public string GenerateHotelId()
        {
            string BookingId = null;
            try
            {
                BookingId = ((from s in context.Users
                              select TravelAwayDBContext.GenerateNewHotelId()).FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return BookingId;
            }
            return BookingId;
        }
         public string GeneratePackageId()
        {
            string BookingId = null;
            try
            {
                BookingId = ((from s in context.Users
                              select TravelAwayDBContext.GenerateNewPackageId()).FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return BookingId;
            }
            return BookingId;
        }
        public string AddBookingDetailsUsingUSP(string AccommodationId, string EmailId, string PackageId, string ContactNo, string Address, DateTime DateOfTravel, Byte NoOfAdult, Byte NoOfChildren)
        {
            int result = -1;
            int returnResult = 0;
            string BookingId= this.GenrateBookingId();
            if (BookingId == null)
            {
                BookingId = "null";
            }
 
            SqlParameter prmBookintgId = new SqlParameter("@BookingId", BookingId);
            SqlParameter prmAccommodationId = new SqlParameter("@AccommodationId", AccommodationId);
            SqlParameter prmEmailId = new SqlParameter("@EmailId", EmailId);
            SqlParameter prmPackageId = new SqlParameter("@PackageId", PackageId);
            SqlParameter prmContactNo = new SqlParameter("@ContactNo", ContactNo);
            SqlParameter prmAddress = new SqlParameter("@Address", Address);
            SqlParameter prmDateOfTravel = new SqlParameter("@DateOfTravel", DateOfTravel);
            SqlParameter prmNoOfAdult = new SqlParameter("@NoOfAdult", NoOfAdult);
            SqlParameter prmNoOfChildren = new SqlParameter("@NoOfChildren", NoOfChildren);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            Console.WriteLine(prmDateOfTravel.Value);
            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddBookingDetails @BookingId,@AccommodationId ,@EmailId,@PackageId,@ContactNo,@Address,@DateOfTravel,@NoOfAdult,@NoOfChildren",
                                              prmReturnResult, prmBookintgId, prmAccommodationId, prmEmailId, prmPackageId, prmContactNo, prmAddress, prmDateOfTravel, prmNoOfAdult,prmNoOfChildren);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return BookingId;
        }

        public string AddAccommodationDetailsUsingUSP(string BookingId, string HotelId, string HotelName, string CityName, Byte Rating, string RoomType, int Cost)
        {
            int result = -1;
            int returnResult = 0;
            string AccommodationId = this.GenerateAccommodationId();

            if(AccommodationId == null)
            {
                AccommodationId = "null";
            }

            SqlParameter prmBookintgId = new SqlParameter("@BookingId", BookingId);
            SqlParameter prmAccommodationId = new SqlParameter("@AccommodationId", AccommodationId);
            SqlParameter prmHotelId = new SqlParameter("@HotelId", HotelId);
            SqlParameter prmHotelName = new SqlParameter("@HotelName", HotelName);
            SqlParameter prmCityName = new SqlParameter("@CityName", CityName);
            SqlParameter prmRating = new SqlParameter("@Rating", Rating);
            SqlParameter prmRoomType = new SqlParameter("@RoomType", RoomType);
            SqlParameter prmCost = new SqlParameter("@Cost", Cost);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddAccommodationDetails @BookingId,@AccommodationId ,@HotelId,@HotelName,@CityName,@Rating,@RoomType,@Cost",
                                              prmReturnResult, prmBookintgId, prmAccommodationId, prmHotelId, prmHotelName, prmCityName, prmRating, prmRoomType, prmCost);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return AccommodationId;
        }

        public int AddRatingUsingUSP(string BookingId, Byte Stars, string Comment)
        {
            int result = -1;
            int returnResult = 0;
            SqlParameter prmBookintgId = new SqlParameter("@BookingId", BookingId);          
            SqlParameter prmStars = new SqlParameter("@Stars", Stars);
            SqlParameter prmComment = new SqlParameter("@Comment", Comment);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddRating @BookingId,@Stars ,@Comment",
                                              prmReturnResult, prmBookintgId, prmStars, prmComment);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return returnResult;
        }

        public int AddQueryUsingUSP(string BookingId, string Status, string Query)
        {
            int result = -1;
            int returnResult = 0;
            SqlParameter prmBookintgId = new SqlParameter("@BookingId", BookingId);
            SqlParameter prmStatus = new SqlParameter("@Status", Status);
            SqlParameter prmQuery = new SqlParameter("@Query", Query);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddQuery @BookingId,@Status ,@Query",
                                              prmReturnResult, prmBookintgId, prmStatus, prmQuery);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return returnResult;
        }

        public int UpdateQueryStatusUSP(string BookingId, string Status)
        {
            int result = -1;
            int returnResult = 0;
            SqlParameter prmBookintgId = new SqlParameter("@BookingId", BookingId);
            SqlParameter prmStatus = new SqlParameter("@Status", Status);
            SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
            prmReturnResult.Direction = System.Data.ParameterDirection.Output;
            try
            {
                result = context.Database
                                .ExecuteSqlRaw("EXEC @ReturnResult = usp_AddQuery @BookingId,@Status ",
                                              prmReturnResult, prmBookintgId, prmStatus);
                returnResult = Convert.ToInt32(prmReturnResult.Value);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                result = -99;
                returnResult = -99;
            }
            return returnResult;
        }

        public List<PackagesDetails> GetAllPackages()
        {
            List<PackagesDetails> packagesDetails = null;
            try
            {
                Console.WriteLine("1");

                packagesDetails = context.PackagesDetails.FromSqlRaw("SELECT * FROM ufn_GetALLPackagesDetails()"
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return packagesDetails;
        }

        public List<PackagesDetails> GetPackagesByCategory(byte CategoryId)
        {
            List<PackagesDetails> packagesDetails = null;
            try
            {
                Console.WriteLine("1");
                SqlParameter prmCategoryId = new SqlParameter("@CategoryId", CategoryId);

                packagesDetails = context.PackagesDetails.FromSqlRaw("SELECT * FROM ufn_GetPackagesDetails(@CategoryId)", prmCategoryId
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return packagesDetails;
        }

        public List<SubPackageDetails> GetSubPackageDetails(string packageName)
        {
            List<SubPackageDetails> subPackagesDetails = null;
            try
            {
                Console.WriteLine("1");
                SqlParameter prmpackageName = new SqlParameter("@packageName", packageName);

                subPackagesDetails = context.SubPackageDetails.FromSqlRaw("SELECT * FROM ufn_GetPackageDetail(@packageName)", prmpackageName
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return subPackagesDetails;
        }

        public int CalculateTotalCost(string BookingId, string AccommodationId)
        {
            int TotalCost = 0;
            try
            {
                TotalCost = ((from s in context.BookPackage
                              select TravelAwayDBContext.CalculateTotalCost(BookingId,AccommodationId)).FirstOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return Convert.ToInt32(TotalCost);
            }
            return Convert.ToInt32(TotalCost);
        }

        public List<Hotels> GetHotelDetails()
        {
            List<Hotels> hotel = null;
            try
            {
                Console.WriteLine("1");
            
                hotel = context.Hotels.FromSqlRaw("SELECT * FROM ufn_GetHotelDetails()"
                                                        ).ToList();
                Console.WriteLine("2--");


            }
            catch (Exception ex)
            {
                throw;
            }
            return hotel;
        }
    }
}

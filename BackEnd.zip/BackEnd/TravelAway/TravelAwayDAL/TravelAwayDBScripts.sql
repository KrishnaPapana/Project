﻿CREATE DATABASE TravelAwayDB
GO
USE TravelAwayDB
GO
IF OBJECT_ID('Roles')  IS NOT NULL
DROP TABLE Roles
GO
IF OBJECT_ID('Users')  IS NOT NULL
DROP TABLE Users
GO
IF OBJECT_ID('usp_RegisterUser')  IS NOT NULL
DROP PROC usp_RegisterUser
GO
IF OBJECT_ID('ufn_ValidateUserCredentials')  IS NOT NULL
DROP FUNCTION ufn_ValidateUserCredentials
GO
IF OBJECT_ID('ufn_GetUserDetails')  IS NOT NULL
DROP FUNCTION ufn_GetUserDetails
GO
IF OBJECT_ID('usp_UpdateUser')  IS NOT NULL
DROP PROC usp_UpdateUser
GO


CREATE TABLE Roles
(
	[RoleId] TINYINT CONSTRAINT pk_RoleId PRIMARY KEY IDENTITY,
	[RoleName] VARCHAR(20) CONSTRAINT uq_RoleName UNIQUE
)
GO 

CREATE TABLE Users
(
	[FirstName] varchar(40) CONSTRAINT chk_FName CHECK(FirstName NOT LIKE '% %') NOT NULL,
	[LastName] varchar(40) CONSTRAINT chk_LName CHECK(LastName NOT LIKE '% %') NOT NULL,
	[EmailId] VARCHAR(50) CONSTRAINT pk_EmailId PRIMARY KEY,
	[UserPassword] VARCHAR(20) NOT NULL,
	[RoleId] TINYINT CONSTRAINT fk_RoleId REFERENCES Roles(RoleId),
	[Gender] CHAR CONSTRAINT chk_Gender CHECK(Gender='F' OR Gender='M') NOT NULL,
	[ContactNo] VARCHAR(11) CONSTRAINT chk_ContactNo CHECK(ContactNo Like '[1-9]%') NOT NULL,
	[DateOfBirth] DATE CONSTRAINT chk_DateOfBirth CHECK(DateOfBirth<GETDATE()) NOT NULL,
	[Address] VARCHAR(200) NOT NULL
)
GO

CREATE FUNCTION ufn_ValidateUserCredentials
(
	@EmailId VARCHAR(50),
    @UserPassword VARCHAR(15)
)
RETURNS INT
AS
BEGIN
	DECLARE @RoleId INT
	SELECT @RoleId=RoleId FROM Users WHERE EmailId=@EmailId AND UserPassword=@UserPassword
	IF(@RoleId IS NULL)
	RETURN -1

	RETURN @RoleId
END
GO

CREATE PROCEDURE usp_RegisterUser
(
	@UserPassword VARCHAR(20),
	@Gender CHAR,
	@EmailId VARCHAR(50),
	@DateOfBirth DATE,
	@ContactNo VARCHAR(11),
	@Address VARCHAR(200),
	@FirstName VARCHAR(40),
	@LastName VARCHAR(40)
)
AS
BEGIN
	DECLARE @RoleId TINYINT
	BEGIN TRY
		IF (LEN(@EmailId)<4 OR LEN(@EmailId)>50 OR (@EmailId IS NULL))
			RETURN -1
		IF (LEN(@UserPassword)<8 OR LEN(@UserPassword)>16 OR (@UserPassword IS NULL))
			RETURN -2
		IF (@Gender<>'F' AND @Gender<>'M' OR (@Gender Is NULL))
			RETURN -3		
		IF (@DateOfBirth>=CAST(GETDATE() AS DATE) OR (@DateOfBirth IS NULL))
			RETURN -4
		IF DATEDIFF(d,@DateOfBirth,GETDATE())<0
			RETURN -5
		IF (@Address IS NULL)
			RETURN -6
		IF(LEN(@FirstName)>40 OR LEN(@LastName)>40 OR (@FirstName IS NULL) OR (@LastName IS NULL))
			RETURN -7
		IF(LEN(@ContactNo)>11 OR (@ContactNo IS NULL))
			RETURN -8

		SELECT @RoleId=RoleId FROM Roles WHERE RoleName='Customer'
		INSERT INTO Users VALUES 
		(@FirstName,@LastName,@EmailId,@UserPassword, @RoleId, @Gender,@ContactNo ,@DateOfBirth, @Address)
		RETURN 1
	END TRY
	BEGIN CATCH
		select ERROR_MESSAGE() as Msg
		RETURN -99
	END CATCH
END
GO


CREATE PROCEDURE usp_UpdateUser
(
	@Gender CHAR,
	@ContactNo VARCHAR(11),
	@EmailId VARCHAR(50),
	@DateOfBirth DATE,
	@Address VARCHAR(200),
	@FirstName VARCHAR(40),
	@LastName VARCHAR(40)
)
AS
BEGIN
	DECLARE @RoleId TINYINT
	BEGIN TRY
		IF (@Gender<>'F' AND @Gender<>'M' OR (@Gender Is NULL))
			RETURN -3		
		IF (@DateOfBirth>=CAST(GETDATE() AS DATE) OR (@DateOfBirth IS NULL))
			RETURN -4
		IF DATEDIFF(d,@DateOfBirth,GETDATE())<0
			RETURN -5
		IF (@Address IS NULL)
			RETURN -6
		IF(LEN(@FirstName)>40 OR LEN(@LastName)>40 OR (@FirstName IS NULL) OR (@LastName IS NULL))
			RETURN -7
		IF(LEN(@ContactNo)>11 OR (@ContactNo IS NULL))
			RETURN -8

		SELECT @RoleId=RoleId FROM Roles WHERE RoleName='Customer'
		UPDATE Users SET 
		Users.Gender= @Gender,Users.ContactNo = @ContactNo , Users.FirstName = @FirstName, Users.LastName=@LastName,Users.DateOfBirth=@DateOfBirth,Users.Address=@Address where Users.EmailId=@EmailId
		RETURN 1
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() as msg
		RETURN -99
	END CATCH
END
GO

CREATE FUNCTION ufn_GetUserDetails(@EmailId VARCHAR(50))
RETURNS TABLE 
AS
RETURN (SELECT FirstName,LastName,Gender,ContactNo,DateOfBirth,Address 
		FROM Users 
		WHERE EmailId=@EmailId)
GO


--insertion scripts for roles
SET IDENTITY_INSERT Roles ON
INSERT INTO Roles (RoleId, RoleName) VALUES (1, 'Customer')
INSERT INTO Roles (RoleId, RoleName) VALUES (2, 'Employee')
SET IDENTITY_INSERT Roles OFF

insert into Users values('siddarth','dwivedi','siddarth@gmail.com','siddarth',2,'M','9848950299','1997-1-1','Delhi')

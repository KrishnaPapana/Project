﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TravelAwayServices.Models
{
    public class PaymentDetails
    {
        [Required]
        public string BookingId { set; get; }
        [Required]
        public string AccommodationId { set; get; }
    }
}

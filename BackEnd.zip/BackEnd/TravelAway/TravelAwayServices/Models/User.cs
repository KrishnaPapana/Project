﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TravelAwayServices.Models
{
    public class User
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w.]{2,4}$")]
        public string EmailId { get; set; }
        [StringLength(16, MinimumLength = 8)]
        public string UserPassword { get; set; }
        [Required]
        public string Gender { get; set; }
        [StringLength(10)]
        public string ContactNo { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public string Address { get; set; }
    }
}

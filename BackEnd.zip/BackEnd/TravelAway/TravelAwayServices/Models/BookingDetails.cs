﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TravelAwayServices.Models
{
    public class BookingDetails
    {
        [Required]
        public string AccomodationId { get; set; }
        [Required]
        public string PackageId { get; set; }
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w.]{2,4}$")]
        public string EmailId { get; set; }
        [StringLength(10)]
        public string ContactNo { get; set; }
        [Required]
        public DateTime DateOfTravel { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public byte NoOfAdult { get; set; }
        [Required]
        public byte NoOfChildren { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TravelAwayServices.Models
{
    public class Rating
    {
        [Required]
        public string BookingId { get; set; }
        [Required]
        public byte Stars { get; set; }
        [Required]
        public string Comment { get; set; }
    }
}

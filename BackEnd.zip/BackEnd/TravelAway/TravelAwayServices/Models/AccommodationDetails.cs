﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace TravelAwayServices.Models
{
    public class AccommodationDetails
    {
        [Required]
        public string BookingId { get; set; }
        [Required]
        public string HotelId { get; set; }
        [Required]
        public string HotelName { get; set; }
        [Required]
        public string CityName { get; set; }
        [Required]
        public byte Rating { get; set; }
        [Required]
        public string RoomType { get; set; }
        [Required]
        public int Cost { get; set; }
    }
}

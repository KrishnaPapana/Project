﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TravelAwayDAL;
using TravelAwayDAL.Models;
using TravelAwayServices.Models;

namespace TravelAwayServices.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TravelAwayController : Controller
    {
        TravelAwayRepository rep = new TravelAwayRepository();
        [HttpGet]
        public JsonResult GetUserDetails(string emailId)
        {
            List<AbstractUser> abstractUsers = new List<AbstractUser>();
            try
            {
                abstractUsers = rep.GetUserDetails(emailId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(abstractUsers);
        }

        [HttpPost]
        //Returns roleId = 1 for Customer, 2 for Employee, -1 for wrong username/pswd, -2 some exception in backend
        public JsonResult ValidateUser(LoginUser userObj)
        {
            int roleId = -2;
            List<AbstractUser> abstractUsers = new List<AbstractUser>();
            UserType userType = new UserType();
            try
            {
                roleId = rep.ValidateUser(userObj.EmailId, userObj.Password);
                if (roleId > 0)
                {
                    abstractUsers = rep.GetUserDetails(userObj.EmailId);
                }

                foreach (var user in abstractUsers)
                {
                    userType.Address = user.Address;
                    userType.RoleId = roleId;
                    userType.FirstName = user.FirstName;
                    userType.LastName = user.LastName;
                    userType.DateOfBirth = user.DateOfBirth;
                    userType.ContactNo = user.ContactNo;
                    userType.Gender = user.Gender;
                    break;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(userType);
        }


        [HttpPost]
        public JsonResult AddUserDetails(User userObj)
        {
            DateTime DOB = Convert.ToDateTime(userObj.DateOfBirth);
            Console.Write(userObj);
            int returnValue = -1;
            bool flag = false;
            try
            {
                returnValue = rep.AddUserDetailsUsingUSP(userObj.FirstName, userObj.LastName, userObj.EmailId, userObj.UserPassword, userObj.Gender, userObj.ContactNo, DOB, userObj.Address);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            if (returnValue == 1)
            {
                flag = true;
            }
            return Json(flag);
        }

        [HttpPut]
        public JsonResult UpdateUserDetails(UpateUser userObj)
        {
            DateTime DOB = Convert.ToDateTime(userObj.DateOfBirth);

            int returnValue = -1;
            bool flag = false;
            try
            {
                returnValue = rep.EditUserDetailsUsingUSP(userObj.FirstName, userObj.LastName, userObj.EmailId, userObj.Gender, userObj.ContactNo, DOB, userObj.Address);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            if (returnValue == 1)
            {
                flag = true;
            }
            return Json(flag);
        }

        //sprint 2

        [HttpPost]
        public JsonResult AddBookingDetails(BookingDetails userObj)
        {
            int returnValue = -1;
            string BookingId = "null";
            bool flag = false;
            try
            {
                BookingId = rep.AddBookingDetailsUsingUSP(userObj.AccomodationId, userObj.EmailId, userObj.PackageId, userObj.ContactNo, userObj.Address, userObj.DateOfTravel, userObj.NoOfAdult, userObj.NoOfChildren);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return Json(BookingId);
        }
        [HttpPost]
        public JsonResult AddAccommodationDetails(AccommodationDetails userObj)
        {
            int returnValue = -1;
            string AccommodationId = "null";
            bool flag = false;
            try
            {
                AccommodationId = rep.AddAccommodationDetailsUsingUSP(userObj.BookingId, userObj.HotelId, userObj.HotelName, userObj.CityName, userObj.Rating, userObj.RoomType, userObj.Cost);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(AccommodationId);
        }



        [HttpPost]
        public JsonResult AddRating(Rating userObj)
        {
            int returnValue = -1;
            bool flag = false;
            try
            {
                returnValue = rep.AddRatingUsingUSP(userObj.BookingId, userObj.Stars, userObj.Comment);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            if (returnValue == 1)
            {
                flag = true;
            }
            return Json(flag);
        }
        [HttpPost]
        public JsonResult AddQuery(Query userObj)
        {
            int returnValue = -1;
            bool flag = false;
            try
            {
                returnValue = rep.AddQueryUsingUSP(userObj.BookingId, userObj.Status, userObj.Question);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            if (returnValue == 1)
            {
                flag = true;
            }
            return Json(flag);
        }


        [HttpGet]
        public JsonResult ReportByCategory()
        {
            List<TravelAwayDAL.Models.ReportByCategory> reports = new List<TravelAwayDAL.Models.ReportByCategory>();
            try
            {
                reports = rep.GetReportByCategories();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(reports);
        }

        [HttpGet]
        public JsonResult ReportByPackageName()
        {
            List<TravelAwayDAL.Models.ReportByPackageName> reports = new List<TravelAwayDAL.Models.ReportByPackageName>();
            try
            {
                reports = rep.GetReportByPackageName();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(reports);
        }

        [HttpGet]
        public JsonResult ReportByMonth()
        {
            List<TravelAwayDAL.Models.ReportByMonth> reports = new List<TravelAwayDAL.Models.ReportByMonth>();
            try
            {
                reports = rep.GetReportByMonth();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(reports);
        }


        [HttpGet]
        public JsonResult GetSubPackageDetails(string packageName)
        {
            List<TravelAwayDAL.Models.SubPackageDetails> packagesDetails = new List<TravelAwayDAL.Models.SubPackageDetails>();
            try
            {
                packagesDetails = rep.GetSubPackageDetails(packageName);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(packagesDetails);
        }


        [HttpGet]
        public JsonResult GetAllPackages()
        {
            List<TravelAwayDAL.Models.PackagesDetails> packagesDetails = new List<TravelAwayDAL.Models.PackagesDetails>();
            try
            {
                packagesDetails = rep.GetAllPackages();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(packagesDetails);
        }


        [HttpGet]
        public JsonResult GetlPackagesByCategoryId(string CategoryId)
        {
            byte Id = Convert.ToByte(CategoryId);

            List<TravelAwayDAL.Models.PackagesDetails> packagesDetails = new List<TravelAwayDAL.Models.PackagesDetails>();
            try
            {
                packagesDetails = rep.GetPackagesByCategory(Id);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(packagesDetails);

        }

        [HttpGet]
        //Returns roleId = 1 for Customer, 2 for Employee, -1 for wrong username/pswd, -2 some exception in backend
        public JsonResult TotalCost(string BookingId,string AccommodationId)
        {
            int totalCost = 0;
            try
            {
                totalCost = rep.CalculateTotalCost(BookingId,AccommodationId);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(totalCost);
        }

        [HttpGet]
        public JsonResult GetHotelDetails()
        {
            List<TravelAwayDAL.Models.Hotels> hotel = new List<TravelAwayDAL.Models.Hotels>();
            try
            {
                hotel = rep.GetHotelDetails();
                hotel.RemoveAt(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return Json(hotel);
        }

    }
}

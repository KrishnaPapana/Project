﻿using System;
using System.Collections.Generic;
using TravelAwayDAL;
using TravelAwayDAL.Models;
namespace TravelAwayConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();
            //byte categoryId = 0;
            //(string FirstName, string LastName, string EmailId, string UserPassword, string Gender, string ContactNo, DateTime DateOfBirth, string Address)
            int returnResult = repository.ValidateUser("Franken@gmail.com", "BSBEV@1234");
            Console.WriteLine(returnResult);
            //if (returnResult != null)
            //{
            //    Console.WriteLine("details added successfully-->"+returnResult.Count );
            //    foreach(AbstractUser i in returnResult)
            //    {
            //        Console.WriteLine(i.FirstName);
            //    }

            //}
            //else
            //{
            //    Console.WriteLine("Some error occurred. Try again!");
            //}
        }
    }
}
